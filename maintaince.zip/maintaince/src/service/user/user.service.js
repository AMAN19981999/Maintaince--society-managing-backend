import { User } from "../../models/user.model.js";
import ErrorHandler from "../../utils/errorHandler.js";
import { generateRandomPassword } from "../../utils/randomPasswrod.js";
import { sendMail } from "../../utils/sendMails.js";

export const createUserService = async (body) => {
  try {
    const isEmailExists = await User.findOne({ email: body.email });
    if (isEmailExists) {
      throw new ErrorHandler("Email already exists", 400);
    }
    const isPhoneExists = await User.findOne({ phone: body.phone });
    if (isPhoneExists) {
      throw new ErrorHandler("Phone number already exists", 400);
    }
    const password = generateRandomPassword();
    console.log(password);

    try {
      const email = await sendMail({
        email: body.email,
        subject: "Admin Credintials",
        template: "login-cred.ejs",
        data: {
          newUser: body.name,
          UserId: `User Id: ${body.email}`,
          Password: `Password: ${password}`,
        },

        cc: [],
        bcc: [],
      });
      console.log(email);
    } catch (err) {
      throw new ErrorHandler(err.message, err.statusCode || 500);
    }
    const user = await User.create({ ...body, password, role: "admin" });

    return user;
  } catch (error) {
    if (error.statusCode) {
      throw error; // Rethrow the caught error
    } else {
      throw new ErrorHandler("Internal Server Error", 500);
    }
  }
};

export const createEngineerService = async (body, userId, workIds) => {
  try {
    console.log("afffffffffffg", body, userId, workIds);

    const isEmailExists = await User.findOne({ email: body.email });
    if (isEmailExists) {
      throw new ErrorHandler("Email already exists", 400);
    }
    const isPhoneExists = await User.findOne({ phone: body.phone });
    if (isPhoneExists) {
      throw new ErrorHandler("Phone number already exists", 400);
    }
    const password = generateRandomPassword();
    console.log(password);

    try {
      await sendMail({
        email: body.email,
        subject: "Admin Credentials",
        template: "login-cred.ejs",
        data: {
          newUser: body.name,
          UserId: `User Id: ${body.email}`,
          Password: `Password: ${password}`,
        },
        cc: [],
        bcc: [],
      });
    } catch (err) {
      throw new ErrorHandler(err.message, err.statusCode || 500);
    }

    const engineer = new User({
      ...body,
      password,
      admin_id: userId,
      work: workIds, // Assign multiple works
      role: "engineer",
    });

    const result = await engineer.save();

    return result;
  } catch (error) {
    if (error.statusCode) {
      throw error; // Rethrow the caught error
    } else {
      throw new ErrorHandler("Internal Server Error", 500);
    }
  }
};

export const createMaintainerService = async (body, userId, propertyIds) => {
  try {
    console.log("afffffffffffg", body, userId, propertyIds);

    const isEmailExists = await User.findOne({ email: body.email });
    if (isEmailExists) {
      throw new ErrorHandler("Email already exists", 400);
    }
    const isPhoneExists = await User.findOne({ phone: body.phone });
    if (isPhoneExists) {
      throw new ErrorHandler("Phone number already exists", 400);
    }
    const password = generateRandomPassword();
    console.log(password);

    try {
      await sendMail({
        email: body.email,
        subject: "Admin Credentials",
        template: "login-cred.ejs",
        data: {
          newUser: body.name,
          UserId: `User Id: ${body.email}`,
          Password: `Password: ${password}`,
        },
        cc: [],
        bcc: [],
      });
    } catch (err) {
      throw new ErrorHandler(err.message, err.statusCode || 500);
    }

    const maintainer = new User({
      ...body,
      password,
      admin_id: userId,
      properties: propertyIds, // Assign multiple properties
      role: "maintainer",
    });

    const result = await maintainer.save();

    return result;
  } catch (error) {
    if (error.statusCode) {
      throw error; // Rethrow the caught error
    } else {
      throw new ErrorHandler("Internal Server Error", 500);
    }
  }
};
