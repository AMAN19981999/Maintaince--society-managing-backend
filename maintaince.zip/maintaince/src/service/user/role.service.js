import { User } from "../../models/user.model.js";
import ErrorHandler from "../../utils/errorHandler.js";
import { Properties } from "../../models/buildingDetail/properties.model.js";

export const deleteService = async (userId) => {
  try {
    // Perform deletion operation on the database

    const updatedUser = await User.findByIdAndUpdate(
      userId,
      { deleted: true },
      { new: true }
    );

    console.log(updatedUser);

    if (!updatedUser) {
      throw new ErrorHandler("User not found", 404);
    }
  } catch (error) {
    if (error.statusCode) {
      throw error;
    } else {
      throw new ErrorHandler("Internal Server Error", 500);
    }
  }
};

export const getlistService = async (role) => {
  try {
    const query = { role: role, deleted: { $ne: true } };
    let users;
    if (role === "maintainer") {
      users = await User.find(query)
        .populate({
          path: "properties",
          model: Properties,
          select: "name",
        })
        .exec();
      console.log("Fetched users for maintainer:", users);
    } else {
      users = await User.find(query)
        .populate({
          path: "work",
          select: "worktype",
        })
        .exec();
      console.log("Fetched users for role other than maintainer:", users);
    }
    if (!users || users.length === 0) {
      throw new ErrorHandler("User not found", 404);
    }
    return users;
  } catch (error) {
    console.error("Error fetching users:", error);
    if (error instanceof ErrorHandler) {
      throw error;
    } else {
      throw new ErrorHandler("Internal Server Error", 500);
    }
  }
};
