
import { SurveyDocument } from "../../models/survey/survey.model.js";
import ErrorHandler from "../../utils/errorHandler.js";
import { uploadToS3 } from "../../utils/s3Utils.js";

//service function for survey create
export const surveyService = async (userId, propertyId, photos, data) => {
    try {

        const { date, notes } = data;
        console.log("body", date, "photos", photos, "properties", propertyId, "user", userId);

        const photoUrls = await Promise.all(
            photos.map(photo => {
                const filename = `${Date.now()}-${photo.originalname}`;
                return uploadToS3(photo.buffer, filename, 'surveys', propertyId);
            })
        );

        const newSurvey = new SurveyDocument({
            date,
            propertyId,
            createdBy: userId,
            photos: photoUrls,
            notes,
        });

        return await newSurvey.save();
    } catch (error) {
        if (error.statusCode) {
            throw error;
        } else {
            throw new ErrorHandler("Internal Server Error", 500);
        }
    }
};


//service function for list survey list
export const serveyListService = async (userId) => {
    try {
        const serveyList = SurveyDocument.find({createdBy: {$in: userId}}).select('-photos -notes').sort({updatedAt: -1}).lean();
        if(serveyList){
            return serveyList;
        }else{
            throw new ErrorHandler("service_not_found", 404);
        }
    } catch (error) {
        if (error.statusCode) {
            throw error;
        } else {
            throw new ErrorHandler("Internal Server Error", 500);
        }
    }
};


//service function for survey details api
export const serveyDetailsService = async (surveyId) => {
    try {
        const serveyDetails = SurveyDocument.findById(surveyId);
        if(serveyDetails){
            return serveyDetails;
        }else{
            throw new ErrorHandler("servey_not_found", 404);
        }
    } catch (error) {
        if (error.statusCode) {
            throw error;
        } else {
            throw new ErrorHandler("Internal Server Error", 500);
        }
    }
}


//service function for survey update api
export const updateSurveyService = async (surveyId, userId, propertyId, photos, data) => {
    try {
        const survey = await SurveyDocument.findById(surveyId);

        if (!survey) {
            throw new ErrorHandler('Survey not found', 404);
        }

        if (survey.createdBy.toString() !== userId.toString()) {
            throw new ErrorHandler('Unauthorized', 403);
        }

        const { notes } = data;

        let photoUrls = [];
        if (photos && photos.length > 0) {
            photoUrls = await Promise.all(
                photos.map(photo => {
                    const filename = `${Date.now()}-${photo.originalname}`;
                    return uploadToS3(photo.buffer, filename, 'surveys', survey.propertyId);
                })
            );
            survey.photos = photoUrls;
        }

        if (propertyId) {
            survey.propertyId = propertyId;
        }

        if (notes) {
            survey.notes = notes;
        }

        return await survey.save();
    } catch (error) {
        if (error.statusCode) {
            throw error;
        } else {
            throw new ErrorHandler('Internal Server Error', 500);
        }
    }
};



//service function for survey delete api
export const deleteSurveyService = async (surveyId, userId) => {
    try {
        const survey = await SurveyDocument.findById(surveyId);

        if (!survey) {
            throw new ErrorHandler('Survey not found', 404);
        }

        if (survey.createdBy.toString() !== userId.toString()) {
            throw new ErrorHandler('Unauthorized', 403);
        }

        // Delete photos from S3
        const deletePhotoPromises = survey.photos.map(photoUrl => deleteFromS3(photoUrl));
        await Promise.all(deletePhotoPromises);

        await SurveyDocument.findByIdAndDelete(surveyId);

    } catch (error) {
        if (error.statusCode) {
            throw error;
        } else {
            throw new ErrorHandler('Internal Server Error', 500);
        }
    }
};