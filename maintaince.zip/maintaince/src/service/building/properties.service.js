import ErrorHandler from "../../utils/errorHandler.js";
import { Properties } from "../../models/buildingDetail/properties.model.js";
import { Department } from "../../models/buildingDetail/department.model.js";

export const createprptyService = async (body, departmentId) => {
  try {
    // console.log(body, departmentId);

    const department = await Department.findById(departmentId);
    if (!department) {
      return res
        .status(404)
        .json({ success: false, message: "Department not found" });
    }

    // console.log("departmmet", department);

    const prpty = await Properties.create({
      ...body,
      department: departmentId,
    });
    // console.log("prpty", prpty);

    return prpty;
  } catch (err) {
    throw new ErrorHandler(err.message, 500);
  }
};

export const prprtylistservice = async () => {
  try {
    const pptylist = await Properties.find().populate('department', 'name');
    return pptylist;
  } catch (error) {
    if (error.statusCode) {
      throw error;
    } else {
      throw new ErrorHandler("Internal Server Error", 500);
    }
  }
};

export const updatePropertyService = async (userId, updateData) => {
  try {
    const propertyUpdate = await Properties.findByIdAndUpdate(
      userId,
      updateData,
      { new: true, runValidators: true }
    );

    if (!propertyUpdate) {
      throw new ErrorHandler("Property not found", 404);
    }

    return propertyUpdate;
  } catch (error) {
    if (error.statusCode) {
      throw error;
    } else {
      throw new ErrorHandler("Internal Server Error", 500);
    }
  }
};

export const deletePropertyService = async (userId) => {
  try {
    const propertyDelete = await Properties.findByIdAndDelete(userId);

    if (!propertyDelete) {
      throw new ErrorHandler("Property not found", 404);
    }

    return propertyDelete;
  } catch (error) {
    if (error.statusCode) {
      throw error;
    } else {
      throw new ErrorHandler("Internal Server Error", 500);
    }
  }
};
