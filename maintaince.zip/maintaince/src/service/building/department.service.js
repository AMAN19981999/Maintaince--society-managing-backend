import ErrorHandler from "../../utils/errorHandler.js";
import { Department } from "../../models/buildingDetail/department.model.js";

export const createdepartmentService = async (body) => {
  try {
    const description = new Department({ ...body });
    const result = await description.save();
    return result;
  } catch (error) {
    if (error.statusCode) {
      throw error;
    } else {
      throw new ErrorHandler("Internal Server Error", 500);
    }
  }
};

export const departmentlstService = async () => {
  try {
    const departmentlist = await Department.find();
    // console.log(departmentlist);
    return departmentlist;
  } catch (error) {
    if (error.statusCode) {
      throw error;
    } else {
      throw new ErrorHandler("Internal Server Error", 500);
    }
  }
};

export const updateDepartmentService = async (userId, updateData) => {
  const departmentUpdate = await Department.findByIdAndUpdate(
    userId,
    updateData,
    { new: true, runValidators: true }
  );

  if (!departmentUpdate) {
    throw new ErrorHandler("Department not found", 404);
  }

  return departmentUpdate;
};
