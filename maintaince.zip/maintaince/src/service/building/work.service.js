import ErrorHandler from "../../utils/errorHandler.js";
import { Work } from "../../models/buildingDetail/work.model.js";

export const createworkService = async (body) => {
  try {
    const workService = new Work({ ...body });
    const result = await workService.save();
    return result;
  } catch (error) {
    if (error.statusCode) {
      throw error;
    } else {
      throw new ErrorHandler("Internal Server Error", 500);
    }
  }
};

export const worklistService = async (body) => {
  try {
    const worklist = await Work.find();
    return worklist;
  } catch (error) {
    if (error.statusCode) {
      throw error;
    } else {
      throw new ErrorHandler("Internal Server Error", 500);
    }
  }
};

export const updateWorkService = async (userId, updateData) => {
  try {
    const workUpdate = await Work.findByIdAndUpdate(userId, updateData, {
      new: true,
      runValidators: true,
    });

    if (!workUpdate) {
      throw new ErrorHandler("Work not found", 404);
    }

    return workUpdate;
  } catch (error) {
    if (error.statusCode) {
      throw error;
    } else {
      throw new ErrorHandler("Internal Server Error", 500);
    }
  }
};
export const deleteWorkService = async (userid) => {
  try {
    const workDelete = await Work.findByIdAndDelete(userid);

    if (!workDelete) {
      throw new ErrorHandler("Work not found", 404);
    }

    return workDelete;
  } catch (error) {
    if (error.statusCode) {
      throw error;
    } else {
      throw new ErrorHandler("Internal Server Error", 500);
    }
  }
};
