import ErrorHandler from "../../utils/errorHandler.js";
import { Ticket } from "../../models/ticket/ticket.model.js";
import { generateRandomTicket } from "../../utils/ticket_id.js";
import { User } from "../../models/user.model.js";

export const ticketdetailService = async (body, userId) => {
  try {
    const ticketnumber = generateRandomTicket();
    const ticket = new Ticket({
      ...body,
      reportedby: userId,
      ticket_no: ticketnumber,
    });
    // console.log(ticketnumber);
    const result = await ticket.save();

    return result;
  } catch (error) {
    if (error.statusCode) {
      throw error;
    } else {
      throw new ErrorHandler("Internal Server Error", 500);
    }
  }
};

export const ticketlistService = async () => {
  try {
    const list = await Ticket.find(
      {},
      "reportedby status description createdAt ticket_no assighnedto"
    ).populate("reportedby", "name email")
    .populate("assighnedto", "name ");

    const updatedList = list.map((ticket) => ({
      ...ticket.toObject(),
      assighnedto: ticket.assighnedto || null,
    }));

    return updatedList;
  } catch (error) {
    if (error.statusCode) {
      throw error;
    } else {
      throw new ErrorHandler("Internal Server Error", 500);
    }
  }
};

export const assighnticketService = async (ticketid, assignedUserId) => {
  try {
    // Verify if the assigned user exists
    const assignedUser = await User.findById(assignedUserId);
    if (!assignedUser) {
      throw new Error("Assigned user not found");
    }

    console.log("assighneduser", assignedUserId);

    // Update the existing ticket with the assigned user's ID
    const updatedTicket = await Ticket.findByIdAndUpdate(
      ticketid,
      { assighnedto: assignedUserId },
      { new: true }
    );
    console.log("assighnedticket", updatedTicket);
    return updatedTicket;
  } catch (error) {
    if (error.statusCode) {
      throw error;
    } else {
      throw new ErrorHandler("Internal Server Error", 500);
    }
  }
};

export const tktdetailService = async (ticketId) => {
  try {
    const ticket = await Ticket.findById(ticketId);
    // console.log(ticket);

    // Check if ticket exists
    if (!ticket) {
      return res.status(404).json({
        success: false,
        message: "Ticket not found",
      });
    }

    return ticket;
  } catch (error) {
    if (error.statusCode) {
      throw error;
    } else {
      throw new ErrorHandler("Internal Server Error", 500);
    }
  }
};
