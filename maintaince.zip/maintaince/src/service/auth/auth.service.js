import { User } from "../../models/user.model.js";

import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import "dotenv/config";
import { generateRandomPassword } from "../../utils/randomPasswrod.js";
import { sendMail } from "../../utils/sendMails.js";
import ErrorHandler from "../../utils/errorHandler.js";

// logic for login

export const login = async (email, password) => {
  try {
    const user = await User.findOne({ email }).select("+password");
    if (!user) {
      throw new ErrorHandler("Email not registered", 400);
    }

    if (user.status !== "ACTIVE" || user.deleted) {
      throw new ErrorHandler("User Not Valid", 401);
    }

    const isPasswordMatch = await bcrypt.compare(password, user.password);
    if (!isPasswordMatch) {
      throw new ErrorHandler("Invalid password", 400);
    }

    const tokenPayload = { id: user._id }; //role:user.role
    const token = jwt.sign(tokenPayload, process.env.JWT_SECRET_KEY, {
      expiresIn: "24h",
    });
    return { id: user._id, token };
  } catch (error) {
    if (error.statusCode) {
      throw error; //retrow the try error
    } else {
      throw new ErrorHandler("Internal Server Error", 500);
    }
  }
};

//logic for forgetpassword

export const forgotPassword = async (email) => {
  try {
    const user = await User.findOne({ email });
    if (!user) throw new ErrorHandler("Email not registered", 404);

    const newPassword = generateRandomPassword();

    user.password = newPassword;
    await user.save();

    await sendMail({
      email: user.email,
      subject: "New Password",
      template: "new-password.ejs",
      data: {
        user: user,
        newPassword: newPassword,
      },
    });

    return {};
  } catch (error) {
    if (error.statusCode) {
      throw error; // Rethrow the caught error
    } else {
      throw new ErrorHandler("Internal Server Error", 500);
    }
  }
};

//logic for resetPassword

export const resetPassword = async (userId, currentPassword, newPassword) => {
  try {
    console.log(userId, currentPassword, newPassword);
    const user = await User.findById(userId).select("+password");

    if (!user) throw new ErrorHandler("User not found", 404);

    const isPasswordMatch = await bcrypt.compare(
      currentPassword,
      user.password
    );
    if (!isPasswordMatch)
      throw new ErrorHandler("Incorrect current password", 400);

    if (!newPassword)
      throw new ErrorHandler("New password cannot be empty", 400);

    user.password = newPassword;
    await user.save();
  } catch (error) {
    if (error.statusCode) {
      throw error; // Rethrow the caught error
    } else {
      throw new ErrorHandler("Internal Server Error", 500);
    }
  }
};
