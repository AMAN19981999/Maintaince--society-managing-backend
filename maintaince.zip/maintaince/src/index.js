import connectDB from "./db/dataBase.js";
import express from "express";
import cors from "cors";
import cookieParser from "cookie-parser";
import "dotenv/config";
import userRouter from "./routes/user.routes.js";
import ticketRouter from "./routes/ticket.routes.js";
import buildingRouter from "./routes/building.routes.js";
import surveyRouter from "./routes/survey.routes.js";

export const app = express();

//port number

const PORT = process.env.PORT || 3000;

//dbconnection
connectDB()
  .then(() => {
    app.listen(PORT, () => {
      console.log("server is running on port no : " + PORT);
    });
  })
  .catch((err) => {
    console.log("Failed to connect to PORT", err);
  });

//middleware

app.use(
  cors({
    origin: "*",
    credentials: true,
  })
);
app.use(express.json({ limit: "100kb" }));
app.use(express.static("public"));
app.use(express.urlencoded({ extended: true, limit: "10mb" }));
app.use(cookieParser());
app.use((err, req, res, next) => {
  // Log the error stack for debugging purposes
  console.error(err.stack);

  // Ensure a default status code and message
  const statusCode = err.statusCode || 500;
  const message = err.message || 'Internal Server Error';

  // Send the response
  res.status(statusCode).json({
    success: false,
    message,
  });
});



//routesimport
app.use("/api", userRouter);
app.use("/api/service", buildingRouter);
app.use("/api/v1", ticketRouter);
app.use("/api/v1/survey/", surveyRouter);
