import express from "express";
import { createSurvey, deleteSurvey, getSurveyDetails, getSurveyList, updateSurvey } from "../controllers/survey/survey.controller.js";
import upload from "../middleware/multer.js";


const surveyRouter = express.Router();

//creating survey
surveyRouter.post("/create/:propertyId", upload.array('photos'), createSurvey);
surveyRouter.get("/get-list", getSurveyList);
surveyRouter.get("/get-details/:surveyId", getSurveyDetails);
surveyRouter.put("/update/:surveyId", upload.array('photos'), updateSurvey);
surveyRouter.delete("/delete/:surveyId", deleteSurvey);


export default surveyRouter;