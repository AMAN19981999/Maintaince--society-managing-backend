import express from "express";
import {
  createDeprtmnt,
  departmnetList,
  updateDepartment,
  deleteDptmnt,
} from "../controllers/buildingdetails/department.controller.js";
import {
  createProperty,
  propertyList,
  updateProperty,
  deleteProperty,
} from "../controllers/buildingdetails/properties.controller.js";
import {
  createWork,
  workList,
  updateWork,
  deleteWork,
} from "../controllers/buildingdetails/work.controller.js";

const buildingRouter = express.Router();

//department routes

buildingRouter.post("/add-department", createDeprtmnt);
buildingRouter.get("/departmentlist", departmnetList);
buildingRouter.post("/edit-department", updateDepartment);
buildingRouter.delete("/delete-department", deleteDptmnt);

//properties routes

buildingRouter.post("/add-property", createProperty);
buildingRouter.get("/propertylist", propertyList);
buildingRouter.post("/edit-property", updateProperty);
buildingRouter.delete("/delete-property", deleteProperty);

// work routes
buildingRouter.post("/create-work", createWork);
buildingRouter.get("/worklist", workList);
buildingRouter.post("/edit-work", updateWork);
buildingRouter.delete("/delete-work", deleteWork);

export default buildingRouter;
