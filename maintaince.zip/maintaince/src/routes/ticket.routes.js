import express from "express";
// import upload from '../middleware/multer.js';
import {
  createTicket,
  getTicketList,
  assighnTicket,
  ticketDetails
} from "../controllers/ticket/ticket.controller.js";

const ticketRouter = express.Router();

ticketRouter.post("/create-ticket", createTicket);
ticketRouter.get("/get-ticketlist", getTicketList);
ticketRouter.post("/ticketassighn",assighnTicket);
ticketRouter.get("/ticket-details",ticketDetails);

export default ticketRouter;
