import express from "express";
import {
  login,
  logout,
  forgetPassword,
  resetPassword,
} from "../controllers/auth/user.controller.js";
import {
  createEngineer,
  createAdmin,
  createMaintainer
} from "../controllers/user/user.controller.js";
import {
  getprofiledata,
  updateprofiledata,
} from "../controllers/common/common.controler.js";
import {
  deleteRole,
  getroleList,
  updateRole,
} from "../controllers/user/role.controller.js";

const userRouter = express.Router();

//useraccount authentication
userRouter.post("/login", login);
userRouter.post("/logout", logout);
userRouter.post("/forget-password", forgetPassword);
userRouter.post("/reset-password", resetPassword);

//create user
userRouter.post("/createAdmin", createAdmin);

//userprofile
userRouter.get("/get-profile", getprofiledata);
userRouter.post("/update-profile", updateprofiledata);

//role
userRouter.post("/create-Engineer", createEngineer);
userRouter.post("/create-maintainer", createMaintainer);

userRouter.post("/deleteuser", deleteRole);
userRouter.post("/role", getroleList);
userRouter.post("/updateUser", updateRole);

export default userRouter;
