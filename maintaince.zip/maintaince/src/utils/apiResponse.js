export const sendApiResponse = (res, options) => {
  const { status, data = {}, message = "", statusCode = 200 } = options;

  return res.status(statusCode).json({
    status,
    data,
    message,
  });
};





