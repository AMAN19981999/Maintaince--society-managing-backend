import path from "path";
import ejs from "ejs";
import nodemailer from "nodemailer";
import "dotenv/config";
import { dirname } from "path";
import { fileURLToPath } from "url";

export const sendMail = async (options) => {
  try {
    const transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: parseInt(process.env.SMTP_PORT),
      service: process.env.SMTP_SERVICE,
      secure: process.env.SMTP_SECURE === "false",
      auth: {
        user: process.env.SMTP_MAIL,
        pass: process.env.SMTP_PASSWORD,
      },
    });

    const { email, subject, template, data, attachments } = options;

    const __dirname = dirname(fileURLToPath(import.meta.url));

    // Get the path to the template
    const templatePath = path.join(__dirname, "../template/mail", template);

    // Render the HTML using EJS
    const html = await ejs.renderFile(templatePath, data);

    // Prepare the mail options
    const mailOptions = {
      from: process.env.SMTP_MAIL,
      to: email,
      subject,
      html,
      attachments: attachments
        ? attachments.map((attachment) =>
            typeof attachment === "string"
              ? { path: attachment }
              : {
                  filename: attachment.originalname,
                  content: attachment.buffer,
                  contentType: attachment.mimetype,
                }
          )
        : [],
    };

    // Send the email
    await transporter.sendMail(mailOptions);
    return true;
  } catch (err) {
    return false;
  }
};
