// ErrorHandler.js

class ErrorHandler extends Error {
  constructor(
    status = false,
    message = " something went wrong",
    statusCode,
    stack = " ",
    errors = []
  ) {
    super(message);
    this.status = status;
    this.message = message;
    this.statusCode = statusCode;
    this.errors = errors;
    if (stack) {
      this.stack = stack;
    } else {
      Error.captureStackTrace(this, this.constructor);
    }
  }
}

export default ErrorHandler;
