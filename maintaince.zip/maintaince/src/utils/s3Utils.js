import AWS from "aws-sdk";
import config from "./config/config.js";
import mime from "mime-types";

AWS.config.update({
  accessKeyId: config.aws.accessKeyId,
  secretAccessKey: config.aws.secretAccessKey,
  region: config.aws.region,
});

const s3 = new AWS.S3();

 export const uploadToS3 = (file, filename, folder, ticketId) => {
  const contentType = mime.contentType(filename) || "application/octet-stream";

  const params = {
    Bucket: config.aws.bucketName,
    Key: folder ? `${folder}/${filename}` : filename,
    Body: file instanceof Buffer ? file : file.buffer,
    ContentType: contentType,
  };

  return new Promise((resolve, reject) => {
    s3.upload(params, (err, data) => {
      if (err) {
        console.error("Error uploading file:", err);
        reject(err);
      } else {
        console.log("File uploaded successfully:", data.Location);
        resolve(data.Location);
      }
    });
  });
};

 export const deleteFromS3 = (fileUrl) => {
  const fileName = fileUrl.split("/").pop();
  if (!fileName) {
    throw new Error("Invalid file URL");
  }

  const params = {
    Bucket: config.aws.bucketName,
    Key: fileName,
  };

  return new Promise((resolve, reject) => {
    s3.deleteObject(params, (err) => {
      if (err) {
        console.error("Error deleting file from S3:", err);
        reject(err);
      } else {
        console.log("File deleted successfully from S3");
        resolve();
      }
    });
  });
};