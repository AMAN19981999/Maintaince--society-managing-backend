export const generateRandomTicket = () => {
  // Define characters to be used in the ticket ID
  const characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  const prefix = "TKT-";
  const length = 7;

  let ticket = prefix;

  // Loop to generate random characters
  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * characters.length);
    ticket += characters[randomIndex];
  }

  return ticket;
};
