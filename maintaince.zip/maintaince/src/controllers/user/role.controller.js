import { CatchAsyncError } from "../../middleware/catchAsyncError.js";
import { verifyAdmin } from "../../middleware/auth.js";
import {
  deleteService,
  getlistService,
} from "../../service/user/role.service.js";
import { User } from "../../models/user.model.js";
import ErrorHandler from "../../utils/errorHandler.js";

export const deleteRole = CatchAsyncError(async (req, res, next) => {
  try {
    const user = await verifyAdmin(req, next);

    const userId = req.query.userId;
    console.log(userId);

    await deleteService(userId);

    res.status(200).json({
      success: true,
      message: "User deleted successfully",
    });
  } catch (error) {
    res
      .status(error.statusCode)
      .json({ success: false, message: error.message });
  }
});

export const getroleList = CatchAsyncError(async (req, res, next) => {
  try {
    const user = await verifyAdmin(req, next);
    const { role } = req.query;

    // console.log(role);
    const userList = await getlistService(role); // Fetch user list
    res.status(200).json({ success: true, data: userList });
  } catch (error) {
    res
      .status(error.statusCode)
      .json({ success: false, message: error.message });
  }
});

// export const updateRole = CatchAsyncError(async (req, res, next) => {
//   try {
//     const user = await verifyAdmin(req, next);
//     // console.log(user);
//     const userId = req.query.userId;
//     const { name, address, language, avatar } = req.body;
//     // Find user by ID and update profile data
//     const updatedUser = await User.findByIdAndUpdate(
//       { _id: userId, admin_id: user._id },

//       { name, address, language, avatar},
//       { new: true, runValidators: true } // To return the updated document and run validators
//     );

//     if (!updatedUser) {
//       return next(new ErrorHandler("User not found", 404));
//     }

//     res
//       .status(200)
//       .json({ success: true, data: updatedUser, message: "Profile Updated" });
//   } catch (error) {
//     res
//       .status(error.statusCode)
//       .json({ success: false, message: error.message });
//   }
// });

export const updateRole = CatchAsyncError(async (req, res, next) => {
  try {
    const user = await verifyAdmin(req, next);
    const userId = req.query.userId;
    const updateData = req.body;

    // Find user by ID and update profile data
    const updatedUser = await User.findOneAndUpdate(
      { _id: userId, admin_id: user._id },
      { $set: updateData },

      { new: true, runValidators: true } // To return the updated document and run validators
    );

    console.log(updatedUser);

    if (!updatedUser) {
      return next(new ErrorHandler("User not found", 404));
    }

    res
      .status(200)
      .json({ success: true, data: updatedUser, message: "Profile Updated" });
  } catch (error) {
    res
      .status(error.statusCode || 500)
      .json({ success: false, message: error.message });
  }
});
