import ErrorHandler from "../../utils/errorHandler.js";
import { CatchAsyncError } from "../../middleware/catchAsyncError.js";
import {
  createEngineerService,
  createUserService,
  createMaintainerService,
} from "../../service/user/user.service.js";
import { verifyAdmin } from "../../middleware/auth.js";

export const createAdmin = CatchAsyncError(async (req, res, next) => {
  try {
    const { name, email, phone, address, language } = req.body;
    const UserData = await createUserService(req.body);
    if (!UserData) {
      return next(new ErrorHandler("User account not found", 404));
    }

    res.status(200).json({
      success: true,
      data: UserData,
      message: "User Created successful",
    });
  } catch (error) {
    res
      .status(error.statusCode)
      .json({ success: false, message: error.message });
  }
});

export const createEngineer = CatchAsyncError(async (req, res, next) => {
  try {
    const user = await verifyAdmin(req, next);
    const userId = user?._id;

    // Parse workId from query parameters and handle multiple values
    const workIds = req.query.userId;
    let workIdArray = [];
    if (typeof workIds === "string") {
      workIdArray = workIds.split(","); // Split comma-separated values into an array
    } else if (Array.isArray(workIds)) {
      workIdArray = workIds; // If it's already an array, use it directly
    }

    const { name, email, phone, address, language } = req.body;
    const engineerData = await createEngineerService(
      req.body,
      userId,
      workIdArray // Pass the array of work IDs to the service
    );
    console.log(engineerData);

    if (!engineerData) {
      return next(new ErrorHandler("Engineer not created", 404));
    }

    res.status(200).json({
      success: true,
      data: engineerData,
      message: "Engineer Created successfully",
    });
  } catch (error) {
    res
      .status(error.statusCode || 500)
      .json({ success: false, message: error.message });
  }
});

export const createMaintainer = CatchAsyncError(async (req, res, next) => {
  try {
    const user = await verifyAdmin(req, next);
    const userId = user?._id;

    // Parse propertyId from query parameters and handle multiple values
    const propertyIds = req.query.userId;
    let propertyIdArray = [];
    if (typeof propertyIds === "string") {
      propertyIdArray = propertyIds.split(","); // Split comma-separated values into an array
    } else if (Array.isArray(propertyIds)) {
      propertyIdArray = propertyIds; // If it's already an array, use it directly
    }

    const { name, email, phone, address, language } = req.body;
    const maintainerData = await createMaintainerService(
      req.body,
      userId,
      propertyIdArray // Pass the array of property IDs to the service
    );

    if (!maintainerData) {
      return next(new ErrorHandler("Maintainer not created", 404));
    }

    res.status(200).json({
      success: true,
      data: maintainerData,
      message: "Maintainer Created successfully",
    });
  } catch (error) {
    res
      .status(error.statusCode || 500)
      .json({ success: false, message: error.message });
  }
});
