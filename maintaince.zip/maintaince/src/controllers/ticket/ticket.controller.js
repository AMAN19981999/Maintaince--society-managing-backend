import { CatchAsyncError } from "../../middleware/catchAsyncError.js";
import { verifyAdmin, verifyMaintainer } from "../../middleware/auth.js";

import {
  ticketdetailService,
  ticketlistService,
  assighnticketService,
  tktdetailService,
} from "../../service/ticket/ticket.service.js";

export const createTicket = CatchAsyncError(async (req, res, next) => {
  try {
    const user = await verifyMaintainer(req, next);
    //     console.log(user);
    const userId = user?._id;

    const { status, description, photo } = req.body;
    const ticketData = await ticketdetailService(req.body, userId);
    if (!ticketData) {
      return next(new ErrorHandler("Ticket not created", 404));
    }
    res.status(200).json({
      success: true,
      data: ticketData,
      message: "Ticket Created successfully",
    });
  } catch (error) {
    res
      .status(error.statusCode || 500)
      .json({ success: false, message: error.message });
  }
});

export const getTicketList = CatchAsyncError(async (req, res, next) => {
  try {
    const ticketlist = await ticketlistService();
    // console.log(ticketlist);
    res.status(200).json({ success: true, data: ticketlist });
  } catch (error) {
    res
      .status(error.statusCode || 500)
      .json({ success: false, message: error.message });
  }
});

export const assighnTicket = CatchAsyncError(async (req, res, next) => {
  try {
    const user = await verifyAdmin(req, next);
    // console.log(user);

    const ticketid = req.query.ticketId;
    // console.log("aaaaaaaaaaaaaaaaaaaaaaa", ticketid);

    const assignedUserId = req.query.userId;
    // console.log(assignedUserId);

    const updatedticket = await assighnticketService(ticketid, assignedUserId);
    // console.log("assssssssssssssssssssss", updatedticket);

    res.status(200).json({
      success: true,
      data: updatedticket,
      message: "Ticket assigned successfully",
    });
  } catch (error) {
    res
      .status(error.statusCode || 500)
      .json({ success: false, message: error.message });
  }
});

export const ticketDetails = CatchAsyncError(async (req, res, next) => {
  try {
    const ticketId = req.query.userId;
    // console.log(ticketId);

    const details = await tktdetailService(ticketId);

    res.status(200  ).json({
      success: true,
      data: details,
      message: "Ticket Details Fetched",
    });
  } catch (error) {
    res
      .status(error.statusCode || 500)
      .json({ success: false, message: error.message });
  }
});
