import { verifyMaintainer } from "../../middleware/auth.js";
import { CatchAsyncError } from "../../middleware/catchAsyncError.js";
import { deleteSurveyService, serveyDetailsService, serveyListService, surveyService, updateSurveyService } from "../../service/survey/survey.service.js";
import ErrorHandler from "../../utils/errorHandler.js";

/*******************************************controller function for creating survey*********************************************************
 ---------------------------------------here only verified maintainer can create survey-----------------------------------------------------*/
export const createSurvey = CatchAsyncError(async (req, res, next) => {
    try {
        const user = await verifyMaintainer(req, next);
        const propertyId = req.params.propertyId;
        const photos = req.files;
        const { date, notes } = req.body;


        if (!propertyId || !photos || !date || !notes) {
            throw new ErrorHandler("Missing required fields", 400);
        }

        const survey = await surveyService(user._id, propertyId, photos, req.body);

        res.status(200).json({
            success: true,
            data: survey,
            message: "survey_created",
        });

    } catch (error) {
        res
            .status(error.statusCode || 500)
            .json({ success: false, message: error.message });
    }
});

//to get all survey list
export const getSurveyList = CatchAsyncError(async (req, res, next) => {
    try {
        const user = await verifyMaintainer(req, next);
        const surveyList = await serveyListService(user._id);
        res.status(200).json({
            success: true,
            data: surveyList,
            message: "survey_list_fetched",
        });
    } catch (error) {
        res
            .status(error.statusCode || 500)
            .json({ success: false, message: error.message });
    }
});

//to get perticular survey details
export const getSurveyDetails = CatchAsyncError(async (req, res, next) => {
    try {
        const user = await verifyMaintainer(req, next);
        const surveyId = req.params.surveyId;
        if (!surveyId) {
            throw new ErrorHandler('Survey ID is required', 400);
        }
        const surveyDetails = await serveyDetailsService(surveyId);
        res.status(200).json({
            success: true,
            data: surveyDetails,
            message: "survey_details_fetched",
        });
    } catch (error) {
        res
            .status(error.statusCode || 500)
            .json({ success: false, message: error.message });
    }
});


//controller function for update survey
export const updateSurvey = CatchAsyncError(async (req, res, next) => {
    try {
        const user = await verifyMaintainer(req, next);
        const surveyId = req.params.surveyId;
        const photos = req.files;
        const { propertyId, notes } = req.body;

        const updatedSurvey = await updateSurveyService(surveyId, user._id, propertyId, photos, { notes });

        res.status(200).json({
            success: true,
            data: updatedSurvey,
            message: 'survey_updated',
        });
    } catch (error) {
        res.status(error.statusCode || 500).json({ success: false, message: error.message });
    }
});


//controller function for delete survey
export const deleteSurvey = CatchAsyncError(async (req, res, next) => {
    try {
        const user = await verifyMaintainer(req, next);
        const surveyId = req.params.surveyId;

        if (!surveyId) {
            throw new ErrorHandler('Survey ID is required', 400);
        }

        await deleteSurveyService(surveyId, user._id);

        res.status(200).json({
            success: true,
            message: 'survey_deleted',
        });
    } catch (error) {
        res.status(error.statusCode || 500).json({ success: false, message: error.message });
    }
});