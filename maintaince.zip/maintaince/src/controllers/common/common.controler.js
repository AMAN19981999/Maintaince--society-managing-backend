import { sendApiResponse } from "../../utils/apiResponse.js";
import { User } from "../../models/user.model.js";
import ErrorHandler from "../../utils/errorHandler.js";
import jwt from "jsonwebtoken";
import "dotenv/config";
import { CatchAsyncError } from "../../middleware/catchAsyncError.js";

// getProfiledata
// export const getprofiledata = CatchAsyncError(async (req, res, next) => {
//   try {
//     const authorizationHeader = req.headers.authorization;
//     if (!authorizationHeader || !authorizationHeader.startsWith("Bearer ")) {
//       return next(new ErrorHandler("Unauthorized user", 401));
//     }
//     const tokenString = authorizationHeader.split(" ")[1];
//     const decodeToken = jwt.verify(tokenString, process.env.JWT_SECRET_KEY);
//     const user = await User.findById(decodeToken.id).select(
//       "-created_at -updated_at -__v  -password "
//     );
//     if (!user) {
//       return next(new ErrorHandler("Unauthorized user", 401));
//     }

//     res.status(200).json({
//       success: true,
//       data: user,
//       message: "Profile Data fetched successful",
//     });
//     // console.log(responseData);
//   }catch (error) {
//     // Use the next() function to pass the error to the error-handling middleware
//     next(error);
//   }
// });

export const getprofiledata = CatchAsyncError(async (req, res, next) => {
  try {
    const authorizationHeader = req.headers.authorization;

    if (!authorizationHeader || !authorizationHeader.startsWith("Bearer ")) {
      return next(new ErrorHandler("Unauthorized user", 401));
    }

    const tokenString = authorizationHeader.split(" ")[1];

    // Log the token to debug
    console.log("Token:", tokenString);

    if (!tokenString) {
      return next(new ErrorHandler("Token is missing", 401));
    }

    let decodeToken;
    try {
      decodeToken = jwt.verify(tokenString, process.env.JWT_SECRET_KEY);
    } catch (err) {
      return next(new ErrorHandler("Invalid or malformed token", 401));
    }

    const user = await User.findById(decodeToken.id).select(
      "-created_at -updated_at -__v -password"
    );

    if (!user) {
      return next(new ErrorHandler("Unauthorized user", 401));
    }

    res.status(200).json({
      success: true,
      data: user,
      message: "Profile Data fetched successfully",
    });
  } catch (error) {
    // Use the next() function to pass the error to the error-handling middleware
    next(error);
  }
});

// edit profile data
export const updateprofiledata = async (req, res, next) => {
  try {
    const authorizationHeader = req.headers.authorization;
    if (!authorizationHeader || !authorizationHeader.startsWith("Bearer ")) {
      return next(new ErrorHandler("Unauthorized user token", 401));
    }
    const tokenString = authorizationHeader.split(" ")[1];
    const decodeToken = jwt.verify(tokenString, process.env.JWT_SECRET_KEY);
    const userId = decodeToken.id;

    const { name, email, phone, address, language, avatar, status } = req.body;

    // Find user by ID and update profile data
    const updatedUser = await User.findByIdAndUpdate(
      userId,
      { name, email, phone, address, language, avatar, status },
      { new: true, runValidators: true } // To return the updated document and run validators
    );

    if (!updatedUser) {
      return next(new ErrorHandler("User not found", 404));
    }

    res
      .status(200)
      .json({ success: true, data: updatedUser, message: "Profile Updated" });
  } catch (error) {
    // Use the next() function to pass the error to the error-handling middleware
    next(error);
  }
};
