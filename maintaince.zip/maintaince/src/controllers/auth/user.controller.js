// import { sendApiResponse } from "../../utils/apiResponse.js";
import ErrorHandler from "../../utils/errorHandler.js";
import * as authService from "../../service/auth/auth.service.js";
// import { User } from "../../models/userModel";
import { verifyAuthorization } from "../../middleware/auth.js";
import { CatchAsyncError } from "../../middleware/catchAsyncError.js";

//Login

export const login = CatchAsyncError(async (req, res, next) => {
  const { email, password } = req.body;
  try {
    const result = await authService.login(email, password);
    res
      .status(200)
      .json({ success: true, data: result, message: "Login successful" });
  } catch (error) {
    res
      .status(error.statusCode)
      .json({ success: false, message: error.message });
  }
});

//Logout
export const logout = async (req, res, next) => {
  try {
    await verifyAuthorization(req, next);
    res.clearCookie("Bearer");

    res
      .status(200)
      .json({ success: true, data: {}, message: "Logout successful" });
  } catch (error) {
    res
      .status(error.statusCode)
      .json({ success: false, message: error.message });
  }
};

//ForgetPassword  sent to mail
export const forgetPassword = CatchAsyncError(async (req, res, next) => {
  try {
    const { email } = req.body;
    const result = await authService.forgotPassword(email);
    // console.log(result);

    res
      .status(200)
      .json({
        success: true,
        data: result,
        message: "Password sent to Mailbox",
      });
  } catch (error) {
    res
      .status(error.statusCode)
      .json({ success: false, message: error.message });
  }
});

//Change Password
export const resetPassword = CatchAsyncError(async (req, res, next) => {
  try {
    const user = await verifyAuthorization(req, next);
    // console.log(user);
    const userId = user?._id;
    const { currentPassword, newPassword, confirmPassword } = req.body;

    if (newPassword !== confirmPassword) {
      return next(
        new ErrorHandler("New password does not match confirm password", 400)
      );
    }

    await authService.resetPassword(
      userId,
      currentPassword,
      newPassword,
      confirmPassword
    );

    res
      .status(200)
      .json({ success: true, data: {}, message: "Password reset successful" });
  } catch (error) {
    res
      .status(error.statusCode)
      .json({ success: false, message: error.message });
  }
});
