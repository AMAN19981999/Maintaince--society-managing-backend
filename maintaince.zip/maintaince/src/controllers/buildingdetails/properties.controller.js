import { CatchAsyncError } from "../../middleware/catchAsyncError.js";
import { verifyAdmin } from "../../middleware/auth.js";
import {
  createprptyService,
  prprtylistservice,
  updatePropertyService,
  deletePropertyService
} from "../../service/building/properties.service.js";
// import { Properties } from "../../models/buildingDetail/properties.model.js";

export const createProperty = CatchAsyncError(async (req, res, next) => {
  // console.log("aaaaaaaaaaaaaaa");
  try {
    await verifyAdmin(req, next);

    const departmentId = req.query.userid;
    // console.log(departmentId);

    const { name, description, icon, status } = req.body;
    const propertydata = await createprptyService(req.body, departmentId);
    if (!propertydata) {
      return next(new ErrorHandler("properties not created", 404));
    }
    res.status(200).json({
      success: true,
      data: propertydata,
      message: "Property Created successfully",
    });
  } catch (error) {
    res
      .status(error.statusCode || 500)
      .json({ success: false, message: error.message });
  }
});

export const propertyList = CatchAsyncError(async (req, res, next) => {
  try {
    const prptylist = await prprtylistservice();
    res.status(200).json({ success: true, data: prptylist });
  } catch (error) {
    res
      .status(error.statusCode || 500)
      .json({ success: false, message: error.message });
  }
});

export const updateProperty = CatchAsyncError(async (req, res, next) => {
  try {
    const user = await verifyAdmin(req, next);
    const userId = req.query.userId;
    const { name, active, description } = req.body;
    const propertyUpdate = await updatePropertyService(userId, {
      name,
      active,
      description,
    });

    res.status(200).json({
      success: true,
      data: propertyUpdate,
      message: "Properties Updated",
    });
  } catch (error) {
    res
      .status(error.statusCode || 500)
      .json({ success: false, message: error.message });
  }
});

export const deleteProperty = CatchAsyncError(async (req, res, next) => {
  try {
    const user = await verifyAdmin(req, next);
    const userId = req.query.userid;
    // console.log(userId);
    const propertyDelete = await deletePropertyService(userId);

    res.status(200).json({
      success: true,
      data: propertyDelete,
      message: "Properties Deleted",
    });
  } catch (error) {
    res
      .status(error.statusCode || 500)
      .json({ success: false, message: error.message });
  }
});
