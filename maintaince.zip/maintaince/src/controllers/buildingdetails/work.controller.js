import { CatchAsyncError } from "../../middleware/catchAsyncError.js";
import { verifyAdmin } from "../../middleware/auth.js";
import {
  createworkService,
  worklistService,
  updateWorkService,
  deleteWorkService,
} from "../../service/building/work.service.js";

export const createWork = CatchAsyncError(async (req, res, next) => {
  try {
    const user = await verifyAdmin(req, next);
    // console.log(user);
    const { worktype, image, description, active } = req.body;
    const work = await createworkService(req.body);
    if (!work) {
      return next(new ErrorHandler("Work not created", 404));
    }
    res.status(200).json({
      success: true,
      data: work,
      message: "Work Created successfully",
    });
  } catch (error) {
    res
      .status(error.statusCode || 500)
      .json({ success: false, message: error.message });
  }
});

export const workList = CatchAsyncError(async (req, res, next) => {
  try {
    const user = await verifyAdmin(req, next);
    // console.log(user);
    const worklist = await worklistService();
    // console.log(worklist);
    res.status(200).json({ success: true, data: worklist });
  } catch (error) {
    res
      .status(error.statusCode || 500)
      .json({ success: false, message: error.message });
  }
});

export const updateWork = CatchAsyncError(async (req, res, next) => {
  try {
    const user = await verifyAdmin(req, next);
    const userid = req.query.userId;
    const { image, description, worktype, active } = req.body;

    const workUpdate = await updateWorkService(userid, {
      image,
      description,
      worktype,
      active,
    });

    res.status(200).json({
      success: true,
      data: workUpdate,
      message: "Work Updated",
    });
  } catch (error) {
    res
      .status(error.statusCode || 500)
      .json({ success: false, message: error.message });
  }
});

export const deleteWork = CatchAsyncError(async (req, res, next) => {
  try {
    const user = await verifyAdmin(req, next);
    const userid = req.query.userId;
    const workDelete = await deleteWorkService(userid);
    if (!workDelete) {
      return next(new ErrorHandler("Work not found", 404));
    }
    res.status(200).json({
      success: true,
      data: workDelete,
      message: "Work Deleted",
    });
  } catch (error) {
    res
      .status(error.statusCode || 500)
      .json({ success: false, message: error.message });
  }
});
