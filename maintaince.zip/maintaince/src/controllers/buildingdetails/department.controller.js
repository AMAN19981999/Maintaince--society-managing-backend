import { CatchAsyncError } from "../../middleware/catchAsyncError.js";
import { verifyAdmin } from "../../middleware/auth.js";
import {
  createdepartmentService,
  departmentlstService,
  updateDepartmentService,
} from "../../service/building/department.service.js";
import { Department } from "../../models/buildingDetail/department.model.js";

export const createDeprtmnt = CatchAsyncError(async (req, res, next) => {
  try {
    const user = await verifyAdmin(req, next);

    const { name, active, image, description } = req.body;
    const descrptn = await createdepartmentService(req.body);

    if (!descrptn) {
      return next(new ErrorHandler("Department not created", 404));
    }

    res.status(200).json({
      success: true,
      data: descrptn,
      message: "Department Created successfully",
    });
  } catch (error) {
    res
      .status(error.statusCode || 500)
      .json({ success: false, message: error.message });
  }
});

export const departmnetList = CatchAsyncError(async (req, res, next) => {
  try {
    const user = await verifyAdmin(req, next);

    const departmentlist = await departmentlstService();
    // console.log(departmentlist);
    res.status(200).json({ success: true, data: departmentlist });
  } catch (error) {
    res.status(404).json({ error: error.message });
  }
});

export const updateDepartment = CatchAsyncError(async (req, res, next) => {
  try {
    const user = await verifyAdmin(req, next);
    const userId = req.query.userId;
    // console.log(userId);

    const { name, image, description, active } = req.body;
    const departmntUpdate = await updateDepartmentService(userId, {
      name,
      image,
      description,
      active,
    });

    res.status(200).json({
      success: true,
      data: departmntUpdate,
      message: "Department Updated",
    });
  } catch (error) {
    res
      .status(error.statusCode || 500)
      .json({ success: false, message: error.message });
  }
});

export const deleteDptmnt = CatchAsyncError(async (req, res, next) => {
  try {
    const user = await verifyAdmin(req, next);
    // console.log(user);
    const userId = req.query.userId;
    // console.log(userId);

    const departmntDelete = await Department.findByIdAndDelete({ _id: userId });

    if (!departmntDelete) {
      return next(new ErrorHandler("Department not found", 404));
    }

    res.status(200).json({
      success: true,
      data: departmntDelete,
      message: "Department Deleted",
    });
  } catch (error) {
    res
      .status(error.statusCode || 500)
      .json({ success: false, message: error.message });
  }
});
