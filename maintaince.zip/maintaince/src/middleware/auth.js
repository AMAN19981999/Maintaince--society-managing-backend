import { User } from "../models/user.model.js";
import jwt from "jsonwebtoken";
import ErrorHandler from "../utils/errorHandler.js";
import "dotenv/config";
// Reusable function to verify token and fetch user
const verifyToken = async (req) => {
  const authorizationHeader = req.headers.authorization;
  if (!authorizationHeader || !authorizationHeader.startsWith("Bearer")) {
    throw new ErrorHandler("Unauthorized", 400);
  }
  const tokenString = authorizationHeader.split(" ")[1];
  try {
    const decodedToken = jwt.verify(tokenString, process.env.JWT_SECRET_KEY);
    const user = await User.findById(decodedToken.id);
    if (!user) {
      throw new ErrorHandler("User not found", 404);
    }
    return user;
  } catch (error) {
    throw new ErrorHandler("Unauthorized", 400);
  }
};
// Function to verify general authorization
export const verifyAuthorization = async (req) => {
  return await verifyToken(req);
};
// Function to verify admin role
export const verifyAdmin = async (req) => {
  const user = await verifyToken(req);
  if (user.role !== "admin") {
    throw new ErrorHandler("Unauthorized", 400);
  }
  return user;
};
// Function to verify maintainer role
export const verifyMaintainer = async (req) => {
  const user = await verifyToken(req);
  if (user.role !== "maintainer") {
    throw new ErrorHandler("Unauthorized", 400);
  }
  return user;
};
// Function to verify Engineer role
export const verifyEngineer = async (req) => {
  const user = await verifyToken(req);
  if (user.role !== "engineer") {
    throw new ErrorHandler("Unauthorized", 400);
  }
  return user;
};
