import mongoose from "mongoose";

const propertieSchema = new mongoose.Schema(
  {
    name: {
      type: String,
    },
    description: {
      type: String,
    },
    active: {
      type: Boolean,
      default: true,
    },

    icon: {
      type: String,
    },

    department: [{
      type: mongoose.Schema.Types.ObjectId,
      ref: "Department",
      required: true,
    }],
    status: {
      type: String,
      enum: ["OK", "NOK"],
    },
  },
  { timestamps: true }
);

export const Properties = mongoose.model("Properties", propertieSchema);
