import mongoose from "mongoose";

const workSchema = new mongoose.Schema(
  {
    worktype: {
      type: String,
    },
    active: {
      type: Boolean,
      default: true,
    },
    image: {
      type: String,
    },
    description: {
      type: String,
    },
  },
  { timestamps: true }
);

export const Work = mongoose.model("Work", workSchema);
