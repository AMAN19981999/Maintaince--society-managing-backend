import mongoose from "mongoose";

const surveySchema = new mongoose.Schema({
    date: {
        type: Date,
        required: true,
    },
    propertyId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Property',
        required: true,
    },
    createdBy: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
        required: true,
    },
    photos: [{
        type: String
    }],
    notes: {
        type: String
    }
}, {
    timestamps: true
});

export const SurveyDocument = mongoose.model('Survey', surveySchema);
