import mongoose from "mongoose";

const ticketSchema = new mongoose.Schema(
  {
    status: {
      type: String,
      enum: ["completed", "pending", "work in progress"],
      default: "pending",
    },
    ticket_no: {
      type: String,

      unique: true,
    },

    description: {
      type: String,
      required: true,
      minlength: 3,
      maxlength: 250,
    },

    photo: {
      type: String,
    },

    reportedby: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },

    assighnedto: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
    },
    starttime: {
      type: Date,
    },
    endtime: {
      type: Date,
    },

    completednotes: {
      type: String,

      maxlength: 250,
    },

    completedimage: {
      type: String,
    },

    reviewedby: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
    },
    rating: {
      type: Number,
      min: 1,
      max: 5,
    },
    acceptancenote: {
      type: String,
      // required: true,
      maxlength: 250,
    },

    rejectedreason: {
      type: String,
      // required: true,
      maxlength: 250,
    },

    rejectionphoto: {
      type: String,
    },
  },

  { timestamps: true }
);

export const Ticket = mongoose.model("Ticket", ticketSchema);
