import mongoose from "mongoose";
import bcrypt from "bcrypt";

const userSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,

      minlength: 3,
      maxlength: 30,
    },
    email: {
      type: String,
      required: [true, "Please enter a valid email address"],
      unique: true,
      minlength: 3,
      maxlength: 30,
      trim: true,
      match: /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/,
    },
    password: {
      type: String,
      required: true,
      minlength: [3, "Please enter your password"],
      maxlength: 30,
      select: false,
    },
    role: {
      type: String,
      enum: ["admin", "engineer", "maintainer"],
      required: true,
    },

    status: {
      type: String,
      required: true,
      enum: ["ACTIVE", "INACTIVE"],
      default: "ACTIVE",
    },
    address: {
      type: String,
      required: true,
      minlength: [3, "Please enter your address"],
      maxlength: 250,
    },
    language: {
      type: String,
    },
    phone: {
      type: Number,
      required: true,

      unique: true,
    },
    admin_id: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
    },

    deleted: { type: Boolean },
    avatar: {
      type: String,
    },
    properties: [{
      type: mongoose.Schema.Types.ObjectId,
      ref: "Property",
    }],

    work: [{
      type: mongoose.Schema.Types.ObjectId,
      ref: "Work",
    }],
  },
  { timestamps: true }
);

//hashing password

userSchema.pre("save", async function (next) {
  if (!this.isModified("password")) {
    return next();
  }
  try {
    const salt = await bcrypt.genSalt(10);
    this.password = await bcrypt.hash(this.password, salt);
    next();
    console.log(this.password);
  } catch (error) {
    next(error);
  }
});

export const User = mongoose.model("User", userSchema);
