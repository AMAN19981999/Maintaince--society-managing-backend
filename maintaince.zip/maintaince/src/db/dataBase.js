import mongoose from "mongoose";
import "dotenv/config";

const dbUsername = process.env.MONGO_USERNAME || "";
const dbPassword = process.env.MONGO_PASSWORD || "";
const dbHost = process.env.MONGO_URI || "localhost";
const dbPort = process.env.MONGO_PORT || "27017";
const dbName = process.env.MONGO_DBNAME;
const authSource = process.env.DB_AUTH_SOURCE || "admin";
const dbUri = `mongodb://${dbUsername}:${dbPassword}@${dbHost}:${dbPort}/${dbName}?authSource=${authSource}&authMechanism=DEFAULT`;

const connectDB = async () => {
  try {
    const connectionInstance = await mongoose.connect(`${dbUri}`);

    console.log(
      `\n MongoDB connected !! DB HOST: ${connectionInstance.connection.host}`
    );
  } catch (e) {
    console.log("Mongodb connection is not connected: " + e.message);
    process.exit(1);
  }
};

export default connectDB;
